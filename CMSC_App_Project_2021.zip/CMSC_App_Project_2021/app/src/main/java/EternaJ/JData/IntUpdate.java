package EternaJ.JData;

public interface IntUpdate {
    int update(int value);
}
