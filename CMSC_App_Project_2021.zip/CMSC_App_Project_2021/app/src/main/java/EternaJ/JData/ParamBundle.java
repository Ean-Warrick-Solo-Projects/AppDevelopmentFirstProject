package EternaJ.JData;

import java.util.ArrayList;
import java.util.Arrays;

public class ParamBundle {
    private ArrayList<Object> parameters;

    public ParamBundle(Object... objects) {
        this.parameters = new ArrayList<>();
        this.parameters.addAll(Arrays.asList(objects));
    }

    public boolean isEmpty() { return this.parameters.isEmpty(); }

    public ArrayList<Object> getParameterList() {
        return this.parameters;
    }

    public Object getParameter(int index) {return this.parameters.get(index); }
}
