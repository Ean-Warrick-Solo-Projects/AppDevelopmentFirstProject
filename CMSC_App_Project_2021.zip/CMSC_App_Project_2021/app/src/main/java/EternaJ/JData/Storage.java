package EternaJ.JData;

import java.util.HashMap;

public class Storage {
    public static HashMap<Object, Object> storage = new HashMap<>();

    public static Object set(Object key, Object value) {
        storage.put(key, value);
        return value;
    }

    public static Object get(Object key) {
        return storage.get(key);
    }

    public static void clear() {
        storage.clear();
    }
}
