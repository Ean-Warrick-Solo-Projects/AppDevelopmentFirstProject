package EternaJ.JData;

import EternaJ.JBind.BindableMethodEvent;
import EternaJ.JBind.Callable;

public class IntValue {
    private int value;
    private final BindableMethodEvent changed;

    public IntValue(int value) {
        this.value = value;
        this.changed = new BindableMethodEvent();
    }

    public void setValue(int value) {
        this.value = value;
        this.changed.fire(this.value);
    }

    public int getValue() {
        return value;
    }

    public int increment(int amount) {
        this.setValue(this.value + amount);
        return this.value;
    }

    public void connect(Callable callable, String key) {
        this.changed.connect(callable, key);
    }

    public void disconnect(String key) {
        this.changed.disconnect(key);
    }

    public void update(IntUpdate intUpdate) {
        this.setValue(intUpdate.update(this.value));
    }

    public static int doubler(int number) {
        return number * 2;
    }

    public static int square(int number) {
        return number * number;
    }
}
