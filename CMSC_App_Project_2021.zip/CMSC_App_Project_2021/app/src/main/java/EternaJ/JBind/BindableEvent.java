package EternaJ.JBind;

import EternaJ.JData.ParamBundle;

import java.util.HashMap;
import java.util.Map;

public class BindableEvent {
    private HashMap<Listener, String> connections;
    private String eventKey;

    public BindableEvent(String eventKey) {
        this.connections = new HashMap<>();
        this.eventKey = eventKey;
        
    }

    public String getEventKey() {
        return this.eventKey;
    }

    public HashMap<Listener, String> getConnections() {
        return this.connections;
    }

    public String connect(Listener listener) {
        if (!this.connections.containsKey(listener)) {
            return this.connections.put(listener, this.eventKey);
        } else {
            return null;
        }
    }

    public String disconnect(Listener listener) {
        return this.connections.remove(listener);
    }

    public void fire(ParamBundle paramBundle) {
        for (Map.Entry<Listener, String> kv : this.connections.entrySet()) {
            Listener listener = kv.getKey();
            String eventKey = kv.getValue();
            Thread thread = new Thread(() -> listener.onEvent(eventKey, paramBundle));
            thread.start();
        }
    }

    public void fire() {
        ParamBundle paramBundle = new ParamBundle();
        for (Map.Entry<Listener, String> kv : this.connections.entrySet()) {
            Listener listener = kv.getKey();
            String eventKey = kv.getValue();
            Thread thread = new Thread(() -> listener.onEvent(eventKey, paramBundle));
            thread.start();
        }
    }
}
