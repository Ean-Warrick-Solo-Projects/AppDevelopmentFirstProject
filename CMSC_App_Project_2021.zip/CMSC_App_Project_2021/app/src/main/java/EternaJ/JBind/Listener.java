package EternaJ.JBind;

import EternaJ.JData.ParamBundle;

public interface Listener {
    void onEvent(String key, ParamBundle paramBundle);
}
