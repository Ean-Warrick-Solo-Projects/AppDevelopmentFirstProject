package EternaJ.JBind;

import EternaJ.JData.ParamBundle;

public interface Callable {
    void call(Object[] objects);
}
