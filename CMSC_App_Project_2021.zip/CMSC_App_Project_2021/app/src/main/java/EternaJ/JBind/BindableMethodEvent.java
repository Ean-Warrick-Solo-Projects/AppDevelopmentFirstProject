package EternaJ.JBind;

import java.util.HashMap;
import java.util.Map;

import EternaJ.JObject.ThreadHandler;

public class BindableMethodEvent {
    private final HashMap<String, Callable> connections;

    public BindableMethodEvent() {
        connections = new HashMap<>();
    }

    public void connect(Callable callable, String key) {
        connections.put(key, callable);
        System.out.println("Added connection: " + key);
    }

    public void disconnect(String key) {
        connections.remove(key);
    }

    public void fire(Object ... parameters) {
            for (Map.Entry<String, Callable> kv : this.connections.entrySet()) {
                Callable callable = kv.getValue();
                Thread newThread = new Thread(() -> callable.call(parameters));
                newThread.start();
                ThreadHandler.waitForCompletion(newThread);
            }
    }
}
