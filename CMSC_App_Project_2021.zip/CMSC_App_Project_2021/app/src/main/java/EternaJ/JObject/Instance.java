package EternaJ.JObject;

public class Instance {
    public Instance() {

    }
}
