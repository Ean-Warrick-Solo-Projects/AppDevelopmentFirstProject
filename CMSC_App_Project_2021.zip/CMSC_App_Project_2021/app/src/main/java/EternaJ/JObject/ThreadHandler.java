package EternaJ.JObject;

public class ThreadHandler {
    public static void waitForCompletion(Thread thread) {
        try {
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
