package com.example.cmsc_app_project_2021;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.example.cmsc_app_project_2021.databinding.ActivityMainBinding;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link HomeworkListFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class HomeworkListFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private LinearLayout linearLayout;
    private ArrayList<Button> buttons;
    private ActivityMainBinding binding;

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private Model viewModel;

    public HomeworkListFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment HomeworkListFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static HomeworkListFragment newInstance(String param1, String param2) {
        HomeworkListFragment fragment = new HomeworkListFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_homework_list, container, false);

        this.linearLayout = v.findViewById(R.id.homeworkLinearList);
        this.buttons = new ArrayList<>();
        this.viewModel = new ViewModelProvider(this).get(Model.class);

        setUp();
        return v;
    }

    @Override
    public void onResume() {
        super.onResume();
        this.setUp();
    }

    private void setUp() {
        System.out.println("Setting up!");
        clearList();
        createList();
    }

    private void startHomeworkInfoActivity(Class selectedClass, Homework selectedHomework) {
        Intent intent = new Intent(getActivity(), HomeworkInfoActivity.class);
        intent.putExtra("className", selectedClass.getName());
        intent.putExtra("classDepartment", selectedClass.getDepartment());
        intent.putExtra("homeworkName", selectedHomework.name);
        intent.putExtra("dueDate", selectedHomework.dueDate);
        startActivity(intent);
    }

    private void clearList() {
        for (Button button : this.buttons) {
            ViewGroup parent = (ViewGroup) button.getParent();
            if (parent != null) {
                parent.removeView(button);
            }
        }
        this.buttons.clear();
    }


    private void createList() {
        for (Class selectedClass : viewModel.getClassList().getList()) {
            System.out.println("Class: " + selectedClass.getName());
            for (Homework selectedHomework : selectedClass.getHomeworkList()) {
                System.out.println("Homework: " + selectedHomework.name);
                if (linearLayout != null) {
                    System.out.println("Not Null");
                    Button newButton = new Button(getActivity());
                    newButton.setLayoutParams(new
                            RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT));
                    newButton.setText(selectedClass.getDepartment() + " " + selectedClass.getName() + "\n" + selectedHomework.name + "\nDue: " + selectedHomework.dueDate);
                    newButton.setTextSize(16);
                    newButton.setOnClickListener(view -> {
                        System.out.println(selectedHomework.name);
                        this.startHomeworkInfoActivity(selectedClass, selectedHomework);
                    });
                    linearLayout.addView(newButton);
                    this.buttons.add(newButton);
                }
            }
        }
    }
}