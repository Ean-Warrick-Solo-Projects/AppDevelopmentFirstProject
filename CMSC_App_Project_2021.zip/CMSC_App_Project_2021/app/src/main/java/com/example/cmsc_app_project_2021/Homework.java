package com.example.cmsc_app_project_2021;

import java.util.Calendar;
import java.util.Date;

public class Homework {
    String dueDate;
    String name;

    public Homework(String name, String dueDate) {
        this.name = name;
        this.dueDate = dueDate;
        //System.out.println(Calendar.getInstance().get(Calendar.DATE));
    }

    public String getName() {
        return name;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }
}
