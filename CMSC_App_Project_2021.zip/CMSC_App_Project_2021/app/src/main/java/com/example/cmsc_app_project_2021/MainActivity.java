package com.example.cmsc_app_project_2021;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentContainer;
import androidx.fragment.app.FragmentContainerView;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.cmsc_app_project_2021.databinding.ActivityMainBinding;
import com.google.android.material.tabs.TabLayout;


public class MainActivity extends AppCompatActivity {

    private Model model;
    private TabLayout tabLayout;
    private FragmentContainerView fragmentContainerView;
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);
        this.tabLayout = binding.tabBar;
        this.fragmentContainerView = binding.pageView;

        setUp(savedInstanceState);
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle saveState) {
        super.onSaveInstanceState(saveState);

    }

    private void notify(String title, String message, String channelId, int notificationId) {
        NotificationService.notify(this, title, message, channelId, notificationId);
    }

    private void onTabSelected(TabLayout.Tab tab) {
        Fragment tabScreen = FragmentHandler.getFragment(tab.getPosition());
        this.switchPageFragment(tabScreen);
    }

    private void switchPageFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.pageView, fragment)
                .commit();
    }

    private void setUp(Bundle savedState) {
        this.model = new ViewModelProvider(this).get(Model.class);
        this.tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {MainActivity.this.onTabSelected(tab);}
            public void onTabUnselected(TabLayout.Tab tab) {}
            public void onTabReselected(TabLayout.Tab tab) {}
        });
        this.tabLayout.selectTab(this.tabLayout.getTabAt(1));
        Controller.activityRefreshed.fire();
    }
}