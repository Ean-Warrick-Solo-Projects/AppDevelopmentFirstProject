package com.example.cmsc_app_project_2021;

import android.content.Context;
import android.content.SharedPreferences;

public class SaveStorage {
    SharedPreferences sharedPreferences;

    public SaveStorage(MainActivity mainActivity) {
        sharedPreferences = mainActivity.getPreferences(Context.MODE_PRIVATE);
    }

    public int getInt(String key) {
        return sharedPreferences.getInt(key, 0);
    }

    public void putInt(int integer) {

    }
}
