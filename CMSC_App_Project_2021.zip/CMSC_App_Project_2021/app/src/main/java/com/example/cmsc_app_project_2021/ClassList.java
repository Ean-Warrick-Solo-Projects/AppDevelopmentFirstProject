package com.example.cmsc_app_project_2021;

import java.util.ArrayList;
import java.util.Arrays;

public class ClassList {
    private ArrayList<Class> list;

    public ClassList() {
        list = new ArrayList<>();
    }

    public void addClass(Class ... classes) {
        list.addAll(Arrays.asList(classes));
    }

    public void addClass(Class newClass) {
        list.add(newClass);
        System.out.println("ADDED CLASS");
    }

    public ArrayList<Class> getList() {
        return list;
    }
}
