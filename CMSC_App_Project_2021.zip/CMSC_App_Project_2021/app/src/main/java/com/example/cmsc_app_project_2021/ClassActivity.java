package com.example.cmsc_app_project_2021;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class ClassActivity extends AppCompatActivity {
    private Button createClassButton;
    private EditText nameEditText;
    private EditText departmentEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class);

        this.createClassButton = findViewById(R.id.createClassButton);
        this.nameEditText = findViewById(R.id.editTextClassName);
        this.departmentEditText = findViewById(R.id.editTextClassDepartment);

        setUp(savedInstanceState);
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle saveState) {
        super.onSaveInstanceState(saveState);
    }

    private void onCreateClassButton(View view) {
        String name = this.nameEditText.getText().toString();
        String department = this.departmentEditText.getText().toString();
        Controller.addClass.fire(name, department);
        finish();
    }

    private void setUp(Bundle savedState) {
        this.createClassButton.setOnClickListener(this::onCreateClassButton);
    }

}