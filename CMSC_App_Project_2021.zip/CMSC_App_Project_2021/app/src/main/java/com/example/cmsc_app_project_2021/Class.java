package com.example.cmsc_app_project_2021;

import java.util.ArrayList;

public class Class {
    String name;
    String department;
    ArrayList<Homework> homeworkList;

    public Class(String name, String department) {
        this.name = name;
        this.department = department;
        this.homeworkList = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void addHomework(Homework homework) {
        System.out.println("Adding homework: " + homework.name);
        this.homeworkList.add(homework);
    }

    public Homework getHomeworkFromNameAndDueDate(String name, String dueDate) {
        Homework selectedHomework = null;
        for (Homework homework : this.homeworkList) {
            if (homework.getName().equals(name) && homework.getDueDate().equals(dueDate)) {
                selectedHomework = homework;
            }
        }
        return selectedHomework;
    }

    public void removeHomework(Homework homework) {
        this.homeworkList.remove(homework);
    }

    public ArrayList<Homework> getHomeworkList() {
        return homeworkList;
    }

    @Override
    public String toString() {
        return "Class{" +
                "name='" + name + '\'' +
                ", department='" + department + '\'' +
                ", homeworkList=" + homeworkList +
                '}';
    }
}
