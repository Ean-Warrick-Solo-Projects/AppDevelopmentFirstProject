package com.example.cmsc_app_project_2021;

import androidx.fragment.app.Fragment;

public class FragmentHandler {
    private static final ClassesFragment classesFragment = new ClassesFragment();
    private static final StatisticFragment statisticFragment = new StatisticFragment();
    private static final HomeworkListFragment homeworkListFragment = new HomeworkListFragment();

    public static Fragment getFragment(int position) {
        if (position == 1) {
            return classesFragment;
        } else if (position == 2) {
            return homeworkListFragment;
        } else {
            return statisticFragment;
        }
    }
}
