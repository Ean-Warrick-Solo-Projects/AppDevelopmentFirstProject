package com.example.cmsc_app_project_2021;

import android.widget.Toast;

public class ToastService {
    public static void textToast(MainActivity mainActivity, String text) {
        Toast.makeText(mainActivity.getBaseContext(), text, Toast.LENGTH_LONG).show();
    }
}
