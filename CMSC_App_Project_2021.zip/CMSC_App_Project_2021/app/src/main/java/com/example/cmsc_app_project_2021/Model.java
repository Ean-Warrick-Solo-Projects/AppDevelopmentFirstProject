package com.example.cmsc_app_project_2021;

import android.view.ViewGroup;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.Objects;

import EternaJ.JData.IntValue;

public class Model extends ViewModel {
    private final static MutableLiveData<ClassList> classList = new MutableLiveData<>();

    public Model() {
        System.out.println("MODEL CREATED");
        if (classList.getValue() == null) {
            classList.setValue(new ClassList());
        }
        Controller.addClass.connect(this::addNewClass, "onAddClass");
        Controller.activityRefreshed.connect(this::onActivityRefreshed, "onRefresh");
    }

    public int getAmountOfClasses() {
        return classList.getValue().getList().size();
    }

    public int getAmountOfHomeworks() {
        int amount = 0;
        for (Class selectedClass : classList.getValue().getList()) {
            for (Homework homework : selectedClass.getHomeworkList()) {
                amount += 1;
            }
        }
        return amount;
    }

    public void addNewClass(Object[] objects) {
        String name = (String) objects[0];
        String department = (String) objects[1];

        System.out.println("Added class: " + name + " | " + department);
        Class newClass = new Class(name, department);
        classList.getValue().addClass(newClass);
        Controller.refreshClassPage.fire(classList.getValue());
    }

    public void removeClass(Class removedClass) {
        classList.getValue().getList().remove(removedClass);
    }

    public void printClasses() {
        for (Class  aClass : classList.getValue().getList()) {
            System.out.println(aClass);
        }
    }

    public ClassList getClassList() {
        return classList.getValue();
    }

    public Class getClassFromNameAndDepartment(String name, String department) {
        Class selected = null;
        for (Class selectedClass : classList.getValue().getList()) {
            if (selectedClass.getName().equals(name) && selectedClass.getDepartment().equals(department)) {
                selected = selectedClass;
            }
        }
        return selected;
    }

    public void onActivityRefreshed(Object[] objects) {
        Controller.refreshClassPage.fire(classList.getValue());
    }
}
