package com.example.cmsc_app_project_2021;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.cmsc_app_project_2021.databinding.ActivityMainBinding;

public class HomeworkActivity extends AppCompatActivity {

    private EditText homeworkNameEditText;
    private EditText dueDateEditText;
    private Button createHomeworkButton;
    private Class selectedClass;
    private Model viewModel;
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homework);

        this.homeworkNameEditText = findViewById(R.id.editTextHomeworkName);
        this.dueDateEditText = findViewById(R.id.editTextHomeworkDate);
        this.createHomeworkButton = findViewById(R.id.createHomeworkButton);
        this.viewModel = new ViewModelProvider(this).get(Model.class);

        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        String department = intent.getStringExtra("department");
        this.selectedClass = this.viewModel.getClassFromNameAndDepartment(name, department);

        setUp();
    }

    private void onCreateHomeworkButton(View view) {
        String homeworkName = this.homeworkNameEditText.getText().toString();
        String homeworkDueDate = this.dueDateEditText.getText().toString();
        Homework newHomework = new Homework(homeworkName, homeworkDueDate);
        this.selectedClass.addHomework(newHomework);
        finish();
    }

    private void setUp() {
        this.createHomeworkButton.setOnClickListener(this::onCreateHomeworkButton);
    }
}