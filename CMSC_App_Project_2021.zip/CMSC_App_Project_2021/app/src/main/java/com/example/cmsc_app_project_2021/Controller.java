package com.example.cmsc_app_project_2021;

import EternaJ.JBind.BindableMethodEvent;

public class Controller {
    // Model to View
    public static BindableMethodEvent refreshClassPage = new BindableMethodEvent();

    // View to Model
    public static BindableMethodEvent addClass = new BindableMethodEvent();
    public static BindableMethodEvent activityRefreshed = new BindableMethodEvent();
}
