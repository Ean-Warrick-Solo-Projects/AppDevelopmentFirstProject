package com.example.cmsc_app_project_2021;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.cmsc_app_project_2021.databinding.ActivityMainBinding;

import java.util.ArrayList;
import java.util.zip.Inflater;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ClassesFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ClassesFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private Button addClassButton;
    private TextView placeholderText;
    private ArrayList<Button> buttons;
    private LinearLayout linearLayout;
    private Model viewModel;
    private ActivityMainBinding binding;

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public ClassesFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment ClassesFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static ClassesFragment newInstance(String param1, String param2) {
        ClassesFragment fragment = new ClassesFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        this.setUp();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_classes, container, false);
        //binding = ActivityMainBinding.inflate(getLayoutInflater());
        this.addClassButton = view.findViewById(R.id.addClassButton);
        this.placeholderText = view.findViewById(R.id.placeholderText);
        this.buttons = new ArrayList<>();
        this.linearLayout = view.findViewById(R.id.classList);
        this.viewModel = new ViewModelProvider(requireActivity()).get(Model.class);

        setUp();
        return view;
    }

    private void startAddClassActivity(View view) {
        Intent intent = new Intent(this.getActivity(), ClassActivity.class);
        startActivity(intent);
    }

    private void startClassInfoActivity(String name, String department) {
        Intent intent = new Intent(this.getActivity(), ClassInfoActivity.class);
        intent.putExtra("name", name);
        intent.putExtra("department", department);
        startActivity(intent);
    }

    public void onRefreshClassPage(Object[] objects) {
        System.out.println("REFRESH PAGE!");
        ClassList classList = (ClassList) objects[0];
        FragmentActivity fragmentActivity = getActivity();

        if (fragmentActivity != null) {
            fragmentActivity.runOnUiThread(() -> {
                ViewGroup v = (ViewGroup) this.placeholderText.getParent();
                if (v != null) {
                    v.removeView(this.placeholderText);
                }
                clearList();
                createList(classList);
            });
        }
    }

    private void clearList() {
        for (Button button : this.buttons) {
            ViewGroup parent = (ViewGroup) button.getParent();
            if (parent != null) {
                parent.removeView(button);
            }
        }
        this.buttons.clear();
    }

    private void createList(ClassList classList) {
        FragmentActivity fragmentActivity = getActivity();

        for (Class newClass : classList.getList()) {
            System.out.println(newClass);
            if (linearLayout != null) {
                System.out.println("Not Null");
                Button newButton = new Button(fragmentActivity);
                newButton.setLayoutParams(new
                        RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT));
                newButton.setText(newClass.getDepartment() + "\n" + newClass.getName());
                newButton.setTextSize(32);
                newButton.setOnClickListener(view -> {
                    System.out.println(newClass.getName());
                    this.startClassInfoActivity(newClass.getName(), newClass.getDepartment());
                });
                linearLayout.addView(newButton);
                this.buttons.add(newButton);
            } else {
                System.out.println("IT IS Null");
            }
        }
    }

    private void setUp() {
        this.addClassButton.setOnClickListener(this::startAddClassActivity);
        Controller.refreshClassPage.disconnect("onRefreshPage");
        Controller.refreshClassPage.connect(this::onRefreshClassPage, "onRefreshPage");
        Object[] objects = new Object[1];
        objects[0] = this.viewModel.getClassList();
        System.out.println("Classes: " + this.viewModel.getClassList().getList().size());
        onRefreshClassPage(objects);
    }
}