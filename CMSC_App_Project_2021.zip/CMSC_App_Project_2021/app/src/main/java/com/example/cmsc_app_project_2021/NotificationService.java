package com.example.cmsc_app_project_2021;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public class NotificationService {
    public static void createChannel(MainActivity main, String title, String channelDescription, String id) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(id, title, importance);
            channel.setDescription(channelDescription);
            NotificationManager notificationManager = main.getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    public static NotificationCompat.Builder buildNotification(MainActivity main, String title, String message, String channelId) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(main, channelId)
                .setSmallIcon(R.drawable.notification_icon)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(new NotificationCompat.BigTextStyle()
                        .bigText(message))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        return builder;
    }

    public static void notify(MainActivity main, String title, String message, String channelId, int notificationId) {
        NotificationCompat.Builder build = buildNotification(main, title, message, channelId);
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(main);
        notificationManager.notify(notificationId, build.build());
    }
}
