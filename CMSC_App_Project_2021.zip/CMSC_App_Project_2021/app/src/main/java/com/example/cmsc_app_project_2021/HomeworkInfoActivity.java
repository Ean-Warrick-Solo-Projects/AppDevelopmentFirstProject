package com.example.cmsc_app_project_2021;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import com.example.cmsc_app_project_2021.databinding.ActivityMainBinding;

public class HomeworkInfoActivity extends AppCompatActivity {

    private EditText homeworkNameEditText;
    private EditText dueDateEditText;
    private ActivityMainBinding binding;
    private Button updateHomeworkNameButton;
    private Button updateDueDateButton;
    private ImageButton deleteHomework;
    private Class selectedClass;
    private Homework selectedHomework;
    private Model viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homework_info);

        this.homeworkNameEditText = findViewById(R.id.homeworkNameEditText);
        this.dueDateEditText = findViewById(R.id.homeworkDueDateEditText);
        this.updateHomeworkNameButton = findViewById(R.id.updateHomeworkNameButton);
        this.updateDueDateButton = findViewById(R.id.updateDueDateButton);
        this.deleteHomework = findViewById(R.id.deleteHomeworkButton);
        this.viewModel = new ViewModelProvider(this).get(Model.class);

        Intent intent = getIntent();
        String homeworkName = intent.getStringExtra("homeworkName");
        String dueDate = intent.getStringExtra("dueDate");
        String className = intent.getStringExtra("className");
        String department = intent.getStringExtra("classDepartment");
        this.selectedClass = this.viewModel.getClassFromNameAndDepartment(className, department);
        this.selectedHomework = this.selectedClass.getHomeworkFromNameAndDueDate(homeworkName, dueDate);
        this.homeworkNameEditText.setText(homeworkName);
        this.dueDateEditText.setText(dueDate);


        setUp();
    }

    private void onUpdateHomeworkNameButton(View view) {
        this.selectedHomework.setName(this.homeworkNameEditText.getText().toString());
        System.out.println("Updated homework name");
    }

    private void onUpdateDueDateButton(View view) {
        this.selectedHomework.setDueDate(this.dueDateEditText.getText().toString());
        System.out.println("Updated due date");
    }

    public void onDeleteHomework(View view) {
        this.selectedClass.removeHomework(this.selectedHomework);
        finish();
    }

    private void setUp() {
        this.updateHomeworkNameButton.setOnClickListener(this::onUpdateHomeworkNameButton);
        this.updateDueDateButton.setOnClickListener(this::onUpdateDueDateButton);
        this.deleteHomework.setOnClickListener(this::onDeleteHomework);
    }
}