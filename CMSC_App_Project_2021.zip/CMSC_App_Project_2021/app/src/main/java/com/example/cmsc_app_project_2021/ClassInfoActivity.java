package com.example.cmsc_app_project_2021;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.example.cmsc_app_project_2021.databinding.ActivityMainBinding;

import java.util.ArrayList;

public class ClassInfoActivity extends AppCompatActivity {
    private Button addHomeworkButton;
    private EditText nameEditText;
    private EditText departmentEditText;
    private Class selectedClass;
    private ArrayList<Button> buttons;
    private LinearLayout linearLayout;
    private Model viewModel;
    private ActivityMainBinding binding;
    private Button updateNameButton;
    private Button updateDepartmentButton;
    private ImageButton deleteClassButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class_info);

        this.addHomeworkButton = findViewById(R.id.addHomeworkButton);
        this.nameEditText = findViewById(R.id.nameEditText);
        this.departmentEditText = findViewById(R.id.departmentEditText);
        this.buttons = new ArrayList<>();
        this.linearLayout = findViewById(R.id.linearHomeworkList);
        this.viewModel = new ViewModelProvider(this).get(Model.class);
        this.updateNameButton = findViewById(R.id.updateNameButton);
        this.updateDepartmentButton = findViewById(R.id.updateDepartmentButton);
        this.deleteClassButton = findViewById(R.id.deleteClassButton);

        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        String department = intent.getStringExtra("department");
        System.out.println(name + " | " + department);
        this.selectedClass =  this.viewModel.getClassFromNameAndDepartment(name, department);
        this.nameEditText.setText(name);
        this.departmentEditText.setText(department);
        setUp();
    }

    public void startHomeworkActivity() {
        Intent intent = new Intent(this, HomeworkActivity.class);
        intent.putExtra("name", this.selectedClass.getName());
        intent.putExtra("department", this.selectedClass.getDepartment());
        startActivity(intent);
    }

    public void onAddHomeworkButton(View view) {
        startHomeworkActivity();
    }

    public void onDeleteClassButton(View view) {
        this.viewModel.removeClass(this.selectedClass);
        finish();
    }
    public void onUpdateNameButton(View view) {
        this.selectedClass.setName(this.nameEditText.getText().toString());
        System.out.println("Updated class name!");
    }

    public void onUpdateDepartmentButton(View view) {
        this.selectedClass.setDepartment(this.departmentEditText.getText().toString());
        System.out.println("Updated department!");
    }

    private void setUp() {
        this.addHomeworkButton.setOnClickListener(this::onAddHomeworkButton);
        this.deleteClassButton.setOnClickListener(this::onDeleteClassButton);
        this.updateNameButton.setOnClickListener(this::onUpdateNameButton);
        this.updateDepartmentButton.setOnClickListener(this::onUpdateDepartmentButton);
        clearList();
        createList();
    }

    private void clearList() {
        for (Button button : this.buttons) {
            ViewGroup parent = (ViewGroup) button.getParent();
            if (parent != null) {
                parent.removeView(button);
            }
        }
        this.buttons.clear();
    }

    @Override
    protected void onResume() {
        super.onResume();
        clearList();
        createList();
    }

    private void startHomeworkInfoActivity(Homework selectedHomework) {
        Intent intent = new Intent(this, HomeworkInfoActivity.class);
        intent.putExtra("className", this.selectedClass.getName());
        intent.putExtra("classDepartment", this.selectedClass.getDepartment());
        intent.putExtra("homeworkName", selectedHomework.name);
        intent.putExtra("dueDate", selectedHomework.dueDate);
        startActivity(intent);
    }

    private void createList() {
        for (Homework selectedHomework : selectedClass.getHomeworkList()) {
            if (linearLayout != null) {
                System.out.println("Not Null");
                Button newButton = new Button(this);
                newButton.setLayoutParams(new
                        RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT));
                newButton.setText(selectedHomework.name + "\nDue: " + selectedHomework.dueDate);
                newButton.setTextSize(16);
                newButton.setOnClickListener(view -> {
                    System.out.println(selectedHomework.name);
                    startHomeworkInfoActivity(selectedHomework);
                });
                linearLayout.addView(newButton);
                this.buttons.add(newButton);
            }
        }
    }
}